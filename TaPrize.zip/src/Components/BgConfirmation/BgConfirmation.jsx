import React from 'react'
import './BgConfirmation.css'

function BgConfirmation() {
  return (
    <div className="container-fluid px-3 NwCls">
    <div className="row">
        <div className="col-12 bgconfirmationimg ">
        
        <h1 className='Notation_h1 conforNewcls text-white'>
        お問い合わせ
        </h1>
        </div>
    </div>
</div>

  )
}

export default BgConfirmation