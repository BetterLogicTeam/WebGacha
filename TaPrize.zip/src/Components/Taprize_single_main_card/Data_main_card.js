import Taprize_single_pic from "../Assets/single_1.svg";
import cat from "../Assets/cat.png";
import green from "../Assets/green.png";
import man from "../Assets/man.png";
import caat from "../Assets/caat.png";
import girls from "../Assets/girls.png";

const Card_Data = [
  {
    Image: Taprize_single_pic,
    Name: "特別賞 -1 特大タオル",
    sr: "0",
  },
  {
    Image: Taprize_single_pic,
    Name: "特別賞 -2 特大タオル",
    sr: "1",
  },
  {
    Image: Taprize_single_pic,
    Name: "特別賞 -3 特大タオル",
    sr: "2",
  },
  {
    Image: cat,
    Name: "A-1 特大タオル",
    sr:"3"

  },
  {
    Image: cat,
    Name: "A-2 特大タオル",
    sr:"4"

  }
  ,
  {
    Image: cat,
    Name: "A-3 特大タオル",
    sr:"5"

  } ,
  {
    Image: green,
    Name: "B-1 特大タオル",
    sr:"6"
  },
  {
    Image: green,
    Name: "B-2 特大タオル",
    sr:"7"
  },
  {
    Image: green,
    Name: "B-3 特大タオル",
    sr:"8"
  },
  {
    Image: green,
    Name: "B-4 特大タオル",
    sr:"9"
  },
  {
    Image: green,
    Name: "B-5 特大タオル",
    sr:"10"
  },
  {
    Image: green,
    Name: "B-6 特大タオル",
    sr:"11"
  },
  {
    Image: man,
    Name: "c-1 特大タオル",
    sr:"12"
  },
  {
    Image: man,
    Name: "c-2 特大タオル",
    sr:"13"
  },
  {
    Image: man,
    Name: "c-3 特大タオル",
    sr:"14"
  },
  {
    Image: man,
    Name: "c-4 特大タオル",
    sr:"15"
  },
  {
    Image: man,
    Name: "c-5 特大タオル",
    sr:"16"
  },
  {
    Image: man,
    Name: "c-6 特大タオル",
    sr:"17"
  }
  ,
  {
    Image: man,
    Name: "c-7 特大タオル",
    sr:"18"
  },
  {
    Image: man,
     Name: "c-8 特大タオル",
    sr:"19"
  },
  {
    Image: man,
     Name: "c-9 特大タオル",
    sr:"20"
  },
  {
    Image: man,
     Name: "c-10 特大タオル",
    sr:"21"
  },
  {
    Image: caat,
     Name: "D-1 特大タオル",
    sr:"22"
  },
  {
    Image: caat,
    Name: "D-2 特大タオル",
    sr:"23"
  },
  {
    Image: caat,
    Name: "D-3 特大タオル",
    sr:"24"
  },
  {
    Image: caat,
    Name: "D-4 特大タオル",
    sr:"25"
  },
  {
    Image: caat,
    Name: "D-5 特大タオル",
    sr:"26"
  },
  {
    Image: caat,
    Name: "D-6 特大タオル",
    sr:"27"
  },
  {
    Image: girls,
     Name: "E-1 特大タオル",
    sr:"28"
  },
  {
    Image: girls,
    Name: "E-2 特大タオル",
    sr:"29"
  },
  {
    Image: girls,
    Name: "E-3 特大タオル",
    sr:"30"
  },
  {
    Image: girls,
    Name: "E-4 特大タオル",
    sr:"31"
  },
  {
    Image: girls,
    Name: "E-5 特大タオル",
    sr:"32"
  },
  {
    Image: girls,
    Name: "E-6 特大タオル",
    sr:"33"
  },
  
  
];

export default Card_Data;

