import React from 'react'
import './Notation.css'


function Notation() {
  return (
   


    <div className="container-fluid px-3 mobile_table NwCls">
        <div className="row">
            <div className="col-12 main_ntaa notation_bor">
            
            <h1 className='Notation_titleMain text-white'>

            特定商取引法に基づく表記
            </h1>
            </div>
        </div>
    </div>


  )
}

export default Notation