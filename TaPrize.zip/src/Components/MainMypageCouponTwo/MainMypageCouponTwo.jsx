import React from 'react'
import MypageCouponContentTwo from '../MypageCouponContentTwo/MypageCouponContentTwo'
import MyPageCouponBg from '../MyPageCouponBg/MyPageCouponBg'

function MainMypageCouponTwo() {
  return (
    <div>
    

    <MyPageCouponBg />
{/* <MyPageCouponBg /> */}
    <MypageCouponContentTwo />
    
    
    
    </div>
  )
}

export default MainMypageCouponTwo