import pic_1 from '../Assets/Taprize materials/image 1.png'
import pic_2 from '../Assets/Taprize materials/image 2.png'
import pic_3 from '../Assets/Taprize materials/image 3.png'
import pic_4 from '../Assets/Taprize materials/image 4.png'
import pic_5 from '../Assets/Taprize materials/image 5.png'
import pic_6 from '../Assets/Taprize materials/image 6.png'


const Data = [
  {
    Image: pic_1,
    Name: "近化ホキ店開い史集ヒ技写ちだリ回9和アヨエサ遊極レ",
    tag: "発売中",
  },
  {
    Image: pic_4,
    Name: "台スマ境報コリホ直西時のご表74更ヘヤ無車のも",
    tag: "発売中",
  },
  {
    Image: pic_6,
    Name: "近化ホキ店開い史集ヒ技写ちだリ回9和アヨエサ遊極レ",
    tag: "発売中",
  },
  {
    Image: pic_1,
    Name: "近化ホキ店開い史集ヒ技写ちだリ回9和アヨエサ遊極レ",
    tag: "発売中",
  },
  {
    Image: pic_4,
    Name: "台スマ境報コリホ直西時のご表74更ヘヤ無車のも",
    tag: "発売中",
  },
  {
    Image: pic_6,
    Name: "近化ホキ店開い史集ヒ技写ちだリ回9和アヨエサ遊極レ",
    tag: "発売中",
  },
  {
    Image: pic_4,
    Name: "台スマ境報コリホ直西時のご表74更ヘヤ無車のも",
    tag: "発売中",
  },
  {
    Image: pic_3,
    Name: "近化ホキ店開い史集ヒ技写ちだリ回9和アヨエサ遊極レ",
    tag: "発売中",
  },
  {
    Image: pic_6,
    Name: "近化ホキ店開い史集ヒ技写ちだリ回9和アヨエサ遊極レ",
    tag: "発売中",
  },
  {
    Image: pic_4,
    Name: "台スマ境報コリホ直西時のご表74更ヘヤ無車のも",
    tag: "発売中",
  },
  {
    Image: pic_6,
    Name: "近化ホキ店開い史集ヒ技写ちだリ回9和アヨエサ遊極レ",
    tag: "発売中",
  },
  
  {
    Image: pic_4,
    Name: "台スマ境報コリホ直西時のご表74更ヘヤ無車のも",
    tag: "発売中",
  },

  {
    Image: pic_2,
    Name: "台スマ境報コリホ直西時のご表74更ヘヤ無車のも",
    tag: "近日発売",
  },
  {
    Image: pic_3,
    Name: "台スマ境報コリホ直西時のご表74更ヘヤ無車のも",
    tag: "近日発売",
  },
  {
    Image: pic_2,
    Name: "台スマ境報コリホ直西時のご表74更ヘヤ無車のも",
    tag: "近日発売",
  },
  {
    Image: pic_3,
    Name: "台スマ境報コリホ直西時のご表74更ヘヤ無車のも",
    tag: "近日発売",
  },
  {
    Image: pic_2,
    Name: "台スマ境報コリホ直西時のご表74更ヘヤ無車のも",
    tag: "近日発売",
  },
  {
    Image: pic_5,
    Name: "台スマ境報コリホ直西時のご表74更ヘヤ無車のも",
    tag: "近日発売",
  },
  {
    Image: pic_2,
    Name: "台スマ境報コリホ直西時のご表74更ヘヤ無車のも",
    tag: "近日発売",
  },
  {
    Image: pic_5,
    Name: "台スマ境報コリホ直西時のご表74更ヘヤ無車のも",
    tag: "近日発売",
  },
  {
    Image: pic_3,
    Name: "台スマ境報コリホ直西時のご表74更ヘヤ無車のも",
    tag: "近日発売",
  },
  {
    Image: pic_5,
    Name: "台スマ境報コリホ直西時のご表74更ヘヤ無車のも",
    tag: "近日発売",
  },
  {
    Image: pic_3,
    Name: "台スマ境報コリホ直西時のご表74更ヘヤ無車のも",
    tag: "近日発売",
  },
  {
    Image: pic_5,
    Name: "台スマ境報コリホ直西時のご表74更ヘヤ無車のも",
    tag: "近日発売",
  },
  {
    Image: pic_6,
    Name: "近化ホキ店開い史集ヒ技写ちだリ回9和アヨエサ遊極レ",
    tag: "販売終了",
  },

  {
    Image: pic_5,
    Name: "台スマ境報コリホ直西時のご表74更ヘヤ無車のも",
    tag: "販売終了",
  },
  {
    Image: pic_5,
    Name: "台スマ境報コリホ直西時のご表74更ヘヤ無車のも",
    tag: "販売終了",
  },

  {
    Image: pic_5,
    Name: "台スマ境報コリホ直西時のご表74更ヘヤ無車のも",
    tag: "販売終了",
  },
  
  {
    Image: pic_3,
    Name: "台スマ境報コリホ直西時のご表74更ヘヤ無車のも",
    tag: "販売終了",
  },
 
 
  
  {
    Image: pic_1,
    Name: "近化ホキ店開い史集ヒ技写ちだリ回9和アヨエサ遊極レ",
    tag: "販売終了",
  },
  {
    Image: pic_6,
    Name: "近化ホキ店開い史集ヒ技写ちだリ回9和アヨエサ遊極レ",
    tag: "販売終了",
  },
  {
    Image: pic_2,
    Name: "台スマ境報コリホ直西時のご表74更ヘヤ無車のも",
    tag: "販売終了",
  },
  {
    Image: pic_1,
    Name: "近化ホキ店開い史集ヒ技写ちだリ回9和アヨエサ遊極レ",
    tag: "販売終了",
  },
  {
    Image: pic_2,
    Name: "台スマ境報コリホ直西時のご表74更ヘヤ無車のも",
    tag: "販売終了",
  },
  {
    Image: pic_1,
    Name: "近化ホキ店開い史集ヒ技写ちだリ回9和アヨエサ遊極レ",
    tag: "販売終了",
  },
  {
    Image: pic_2,
    Name: "台スマ境報コリホ直西時のご表74更ヘヤ無車のも",
    tag: "販売終了",
  },
];

export default Data;

